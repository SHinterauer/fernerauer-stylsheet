---
title: Blockquote
info: Blockquotes are used to emphasise a portion of the body content.
---

{% include pattern_block.html url='/src/patterns/components/blockquote/blockquote.html' %}