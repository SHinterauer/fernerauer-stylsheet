---
title: Label
info: Use labels to highlight content and draw attention.
---

{% include pattern_block.html url='/src/patterns/components/label/label.html' %}