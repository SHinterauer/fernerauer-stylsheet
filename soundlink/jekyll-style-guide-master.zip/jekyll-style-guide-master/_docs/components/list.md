---
title: List
info: Lists are used to group and order text.
---

{% include pattern_block.html url='/src/patterns/components/list/unordered.html' %}

{% include pattern_block.html url='/src/patterns/components/list/ordered.html' %}