---
title: Branding
info: Brand assets used in this system.
---

{% include pattern_block.html url='/src/patterns/foundations/branding/icons.html' %}

{% include pattern_block.html url='/src/patterns/foundations/branding/heros.html' %}