---
title: Color
info: Colors used in this system. 
---

{% include pattern_block.html url='/src/patterns/foundations/color/primary-colors.html' %}

{% include pattern_block.html url='/src/patterns/foundations/color/accent-colors.html' %}