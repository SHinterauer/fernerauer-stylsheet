---
title: Full Width
---

{% include pattern_block.html url='/src/patterns/templates/full-width/full-width.html' %}